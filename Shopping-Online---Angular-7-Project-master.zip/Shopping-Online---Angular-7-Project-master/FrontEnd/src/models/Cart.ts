export interface Cart {
  id: string;
  userId: string; // user prop
  creationDate: Date;  // new Date
}
