export interface Product {
  id: string;
  name: string;
  catagoryId: string;
  price: number;
  imgUrl: string;
}
