export interface Catagory {
  id: string;
  catagoryName: string; // user prop
}
