export interface CartProduct {
  id: string;
  cartId: string;
  productId: string;
  productName: string;
  amount: number;
  totalPrice: number;
}
